from tkinter import *
from tkinter import messagebox

questions = ["What is the national bird of Bhutan?", "Who is the first King of Bhutan?",
             "Who is the first Prime Minister of Bhutan?", "What is the capital of Bhutan?"]

answers= [['raven','eagle','crow','peacock'],
          ['Jigme Wangchuk','Jigme Dorji Wangchuk','Jigme Singye Wangchuk','Ugyen Wangchuk'],
          ['Dr. Lotay Tshering', 'Tshering Tobgay', 'Jigme Y Thinley', 'Sangay Nidup'],
          ['Paro', 'Thimphu', 'Trongsa', 'Bumthang']]

question_index=0
points=0
p=0    
def main():
    def back():
        global question_index
        global points
        question_index=0
        points=0
        root.destroy()
        import main_start
        main_start.start_main_page()

    def next_q():
        global question_index
        question_index=question_index+1
        if question_index==len(questions):
            root.destroy()
            import last
            last.main()
        else:
            q.configure(text=questions[question_index])
            a_rd1.configure(text=answers[question_index][0])
            a_rd2.configure(text=answers[question_index][1])
            a_rd3.configure(text=answers[question_index][2])
            a_rd4.configure(text=answers[question_index][3])
            choice.set(0)#resetting the radiobuttons
                                                            
    def submit():
        global points
        global p
        global question_index
        if question_index==0:
            if choice.get()==1:
                points += 5
                score_update()
            else:
                wrong()
            next_q()
                
        elif question_index==1:
            if choice.get()==4:
                points += 5
                score_update()
            else:
                wrong()
            next_q()

        elif question_index==2:
            if choice.get()==3:
                points += 5
                score_update()
            else:
                wrong()
            next_q()

        elif question_index==3:
            if choice.get()==2:
                points += 5
                score_update()
            else:
                wrong()
            question_index=0
            p=points
            points=0
            root.destroy()
            import last
            last.main(p)

    def score_update():
        score.configure(text="Score:- " + str(points))
        messagebox.showinfo('Correct', "Correct Answer.. Keep it Up!")

    def wrong():
        messagebox.showerror('Wrong', "Sorry...The answer is wrong")
        
    root = Tk()
    root.geometry("600x500+300+50")
    root.resizable(0, 0)
    root.title("GK on Bhutan")
    root.configure(background="#e6fff5")
    root.iconbitmap(r'quizee_logo_.ico')

    choice=IntVar()   

    img = PhotoImage(file="back.png")
    Button(root,image=img,bg='#e6fff5', border=0, justify='center',command=back).pack(anchor='nw', pady=10, padx=10)

    score = Label(text="Score:- 0",pady=10,bg="#e6fff5",fg="#000000",font="Titillium  14 bold")
    score.pack(anchor="n")

    q = Label(text=questions[question_index],pady=10,bg="#e6fff5",fg="#000000",font="Titillium  15 bold")
    q.pack()
    
    a_rd1=Radiobutton(text=answers[question_index][0], font=('Cambria',12), variable=choice, value=1)
    a_rd1.pack(pady=7)
    
    a_rd2=Radiobutton(text=answers[question_index][1],font=('Cambria',12), variable=choice, value=2)
    a_rd2.pack(pady=7)

    a_rd3=Radiobutton(text=answers[question_index][2],font=('Cambria',12), variable=choice, value=3)
    a_rd3.pack(pady=7)

    a_rd4=Radiobutton(text=answers[question_index][3],font=('Cambria',12), variable=choice, value=4)
    a_rd4.pack(pady=7)
    
    submit = Button(text="Submit",width=18,borderwidth=8,font=("", 13),fg="#000000",bg="#99ffd6",command=submit)
    submit.pack(pady=(10, 20))
          
    root.mainloop()

