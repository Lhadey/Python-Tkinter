from tkinter import *

def main(p):

    def restart():
        root.destroy()
        import questions
        questions.main()

    def Quit():
        root.destroy()
         
    root = Tk()
    root.geometry("380x380+300+50")
    root.resizable(0, 0)
    root.title("GK on Bhutan")
    root.configure(background="#e6fff5")
    root.iconbitmap(r'quizee_logo_.ico')
    img1 = PhotoImage(file="back.png")
 
    Label(root, text="End of the Quiz!!", fg="blue", font=("Cambria 15 bold")).pack(pady=40)
    Label(root, text="Your score is: "+str(p), font=("Calibri 13")).pack(pady=20)

    btn = Button(root, text="Restart",width=18,borderwidth=8,fg="#000000",bg="#99ffd6",command=restart)
    btn.pack(pady=20, padx=10)

    quit_btn = Button(root, text="Quit",width=18,borderwidth=8,fg="#000000",bg="#99ffd6",command=Quit)
    quit_btn.pack(pady=(20, 10))

    root.mainloop()

