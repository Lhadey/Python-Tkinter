from tkinter import *

def start_main_page():
    def start_game():
        root.destroy()
        import questions
        questions.main()
        
    root = Tk()
    root.geometry("500x500+300+50")
    root.resizable(0, 0)
    root.title("Quiz")
    root.configure(background="#e6fff5")
    root.iconbitmap(r'quizee_logo_.ico')

    img = PhotoImage(file="quiz.png")

    Label(root, image=img, bg='#e6fff5').pack(pady=(50, 0))

    Button(root, text="Start", width=18, borderwidth=8, fg="#000000", bg="#99ffd6",
           font=("", 13), cursor="hand2", command=start_game).pack(pady=(50, 20))

    root.mainloop()

start_main_page()
    
